#LEIA UM ARQUIVO CSV SIMPLES (EX: NOME, IDADE) E MOSTRE EM FORMATO DE TABELA
import csv

with open('arquivo.csv', 'r') as arquivo:
    leitor_csv = csv.reader(arquivo)

#    next(leitor_csv)         (pula a primeira linha)
    
    for linha in leitor_csv:
        print(linha)
    
